import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Music, Play, ChevronDown, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Button } from './ui/button';

export function PerformanceSection() {
  const [expandedPerformance, setExpandedPerformance] = useState<string | null>(null);

  const performances = [
    {
      id: 'hyangbalmu',
      title: '향발무',
      description: '향을 피우며 추는 우아한 궁중무용으로, 정숙하고 절제된 아름다움을 표현합니다.',
      details: '조선시대 궁중에서 중요한 의식이나 연회 때 추어지던 대표적인 궁중무용입니다. 향로를 들고 추는 춤으로, 향의 은은한 향기와 함께 무용수의 우아한 움직임이 조화를 이룹니다.',
      duration: '약 15분',
      performers: '궁중무용단 4명',
      image: 'https://images.unsplash.com/photo-1590501754285-3f90ff9449a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMGtvcmVhbiUyMHBlcmZvcm1hbmNlJTIwZGFuY2V8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 'yedomu',
      title: '예도무',
      description: '궁중 의례에서 추어지는 격식 있는 춤으로, 두 가지 세부 프로그램이 있습니다.',
      details: '예도무는 궁중의 중요한 의식에서 추어지는 격식있는 무용입니다. 무산향과 춘앵전 두 작품으로 구성되어 있으며, 각각 다른 정서와 아름다움을 표현합니다.',
      duration: '약 25분',
      performers: '궁중무용단 6명',
      image: 'https://images.unsplash.com/photo-1590501754285-3f90ff9449a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMGtvcmVhbiUyMHBlcmZvcm1hbmNlJTIwZGFuY2V8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      subPerformances: [
        {
          id: 'musanhyang',
          title: '무산향',
          description: '산의 향기를 무용으로 표현한 작품으로, 자연의 아름다움과 조화를 담고 있습니다.',
          duration: '약 12분'
        },
        {
          id: 'chunaengjeon',
          title: '춘앵전',
          description: '봄날의 꾀꼬리를 형상화한 춤으로, 생동감 넘치는 움직임이 특징입니다.',
          duration: '약 13분'
        }
      ]
    },
    {
      id: 'seoljanggo',
      title: '설장고춤',
      description: '장고의 리듬에 맞춰 추는 역동적이고 화려한 전통 무용입니다.',
      details: '장고의 다양한 리듬과 함께 추어지는 한국의 대표적인 전통 무용입니다. 무용수의 화려한 움직임과 장고의 리듬이 어우러져 관객들에게 깊은 감동을 선사합니다.',
      duration: '약 20분',
      performers: '전통무용단 8명',
      image: 'https://images.unsplash.com/photo-1590501754285-3f90ff9449a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMGtvcmVhbiUyMHBlcmZvcm1hbmNlJTIwZGFuY2V8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card rounded-2xl p-6 text-center"
      >
        <div className="flex items-center justify-center gap-2 mb-4">
          <Music className="text-white" size={24} />
          <h2 className="text-white">궁중 전통공연</h2>
        </div>
        <p className="text-white/80">
          조선왕조의 우아한 궁중무용을 감상하며 전통문화의 깊이를 느껴보세요.
        </p>
      </motion.div>

      <div className="space-y-4">
        {performances.map((performance) => {
          const isExpanded = expandedPerformance === performance.id;
          
          return (
            <motion.div
              key={performance.id}
              className="glass-card rounded-2xl overflow-hidden"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <button
                onClick={() => setExpandedPerformance(isExpanded ? null : performance.id)}
                className="w-full p-4 flex items-center justify-between text-left"
              >
                <div className="flex items-center gap-3">
                  <Play size={20} className="text-white" />
                  <div>
                    <h3 className="text-white">{performance.title}</h3>
                    <p className="text-white/70 text-sm">{performance.description}</p>
                  </div>
                </div>
                {isExpanded ? <ChevronDown className="text-white" /> : <ChevronRight className="text-white" />}
              </button>
              
              {isExpanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-4 pb-4"
                >
                  <div className="w-full h-40 rounded-lg overflow-hidden mb-4">
                    <ImageWithFallback
                      src={performance.image}
                      alt={performance.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="space-y-3">
                    <p className="text-white/80">{performance.details}</p>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-white/10 rounded-lg p-3">
                        <p className="text-white/70 text-sm">공연시간</p>
                        <p className="text-white">{performance.duration}</p>
                      </div>
                      <div className="bg-white/10 rounded-lg p-3">
                        <p className="text-white/70 text-sm">출연진</p>
                        <p className="text-white">{performance.performers}</p>
                      </div>
                    </div>

                    {performance.subPerformances && (
                      <div className="mt-4">
                        <h4 className="text-white mb-3">세부 프로그램</h4>
                        <div className="space-y-2">
                          {performance.subPerformances.map((subPerf) => (
                            <div key={subPerf.id} className="bg-white/5 rounded-lg p-3">
                              <div className="flex justify-between items-start">
                                <div className="flex-1">
                                  <h5 className="text-white">{subPerf.title}</h5>
                                  <p className="text-white/70 text-sm mt-1">{subPerf.description}</p>
                                </div>
                                <span className="text-white/60 text-xs ml-2">{subPerf.duration}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-card rounded-2xl p-6"
      >
        <h3 className="text-white mb-4">공연 관람 안내</h3>
        <div className="space-y-3 text-white/80">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>공연은 명정전 앞마당에서 진행됩니다.</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>좌석은 선착순으로 배정되며, 편안한 관람을 위해 미리 자리를 잡아주세요.</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>공연 중 사진 촬영은 가능하나, 플래시는 사용하지 말아주세요.</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>공연 시간은 총 60분 정도 소요될 예정입니다.</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}