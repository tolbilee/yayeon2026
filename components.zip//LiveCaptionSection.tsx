import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Type, Play, Pause, Volume2, VolumeX } from 'lucide-react';
import { Button } from './ui/button';

export function LiveCaptionSection() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentCaption, setCurrentCaption] = useState('');
  const [currentTime, setCurrentTime] = useState(0);

  // 모의 자막 데이터
  const captions = [
    { time: 0, text: '창경궁 궁중연회에 오신 여러분을 환영합니다.' },
    { time: 3, text: '오늘 저희와 함께 조선왕조의 아름다운 전통을 체험해보시겠습니다.' },
    { time: 8, text: '먼저 향발무 공연이 시작됩니다.' },
    { time: 12, text: '향로에서 피어오르는 은은한 향기와 함께...' },
    { time: 16, text: '무용수들의 우아한 움직임을 감상해주세요.' },
    { time: 20, text: '이어서 예도무 중 무산향이 공연됩니다.' },
    { time: 25, text: '산의 향기를 무용으로 표현한 아름다운 작품입니다.' },
    { time: 30, text: '마지막으로 설장고춤의 역동적인 리듬을 느껴보세요.' },
    { time: 35, text: '감상해주셔서 감사합니다.' }
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          const newTime = prev + 1;
          
          // 현재 시간에 맞는 자막 찾기
          const currentCaptionData = captions.find(caption => 
            caption.time <= newTime && 
            (captions.find(c => c.time > newTime)?.time || Infinity) > newTime
          );
          
          if (currentCaptionData) {
            setCurrentCaption(currentCaptionData.text);
          }
          
          // 마지막 자막이 끝나면 처음으로 돌아가기
          if (newTime >= 40) {
            return 0;
          }
          
          return newTime;
        });
      }, 1000);
    }
    
    return () => clearInterval(interval);
  }, [isPlaying]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card rounded-2xl p-6 text-center"
      >
        <div className="flex items-center justify-center gap-2 mb-4">
          <Type className="text-white" size={24} />
          <h2 className="text-white">실시간 자막</h2>
        </div>
        <p className="text-white/80">
          공연 중 실시간으로 제공되는 자막 서비스로 더욱 깊이 있는 관람이 가능합니다.
        </p>
      </motion.div>

      {/* Live Caption Display */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-card rounded-2xl p-6"
      >
        <div className="text-center mb-6">
          <h3 className="text-white mb-2">실시간 자막 미리보기</h3>
          <p className="text-white/70 text-sm">실제 공연 중에는 무대와 동기화되어 표시됩니다</p>
        </div>

        {/* Caption Display Area */}
        <div className="bg-black/30 rounded-xl p-6 mb-6 min-h-[120px] flex items-center justify-center">
          <motion.p
            key={currentCaption}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-white text-center text-lg leading-relaxed"
          >
            {currentCaption || '자막이 여기에 표시됩니다...'}
          </motion.p>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsPlaying(!isPlaying)}
              className="text-white hover:bg-white/20"
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} />}
              {isPlaying ? '일시정지' : '재생'}
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMuted(!isMuted)}
              className="text-white hover:bg-white/20"
            >
              {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
              {isMuted ? '음소거' : '음성'}
            </Button>
          </div>
          
          <span className="text-white/70 text-sm">
            {formatTime(currentTime)} / {formatTime(40)}
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-white/20 rounded-full h-2 mb-4">
          <motion.div
            className="bg-white rounded-full h-2"
            initial={{ width: 0 }}
            animate={{ width: `${(currentTime / 40) * 100}%` }}
            transition={{ duration: 0.1 }}
          />
        </div>
      </motion.div>

      {/* Features */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-card rounded-2xl p-6"
      >
        <h3 className="text-white mb-4">실시간 자막 기능</h3>
        <div className="grid grid-cols-1 gap-4">
          <div className="bg-white/10 rounded-lg p-4">
            <h4 className="text-white mb-2">정확한 동기화</h4>
            <p className="text-white/80 text-sm">
              공연과 완벽하게 동기화된 자막으로 놓치는 부분 없이 관람하실 수 있습니다.
            </p>
          </div>
          
          <div className="bg-white/10 rounded-lg p-4">
            <h4 className="text-white mb-2">다국어 지원</h4>
            <p className="text-white/80 text-sm">
              한국어, 영어, 중국어, 일본어 자막을 선택하여 이용하실 수 있습니다.
            </p>
          </div>
          
          <div className="bg-white/10 rounded-lg p-4">
            <h4 className="text-white mb-2">접근성 향상</h4>
            <p className="text-white/80 text-sm">
              청각 장애인분들도 공연을 완전히 즐기실 수 있도록 도움을 드립니다.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Usage Instructions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-card rounded-2xl p-6"
      >
        <h3 className="text-white mb-4">이용 안내</h3>
        <div className="space-y-3 text-white/80">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>공연 시작 10분 전부터 자막 서비스가 활성화됩니다.</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>모바일 앱에서 언어를 선택하여 이용하실 수 있습니다.</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>화면 밝기를 조절하여 다른 관객에게 방해가 되지 않도록 해주세요.</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>자막은 공연 종료 후에도 다시 볼 수 있습니다.</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}