import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Utensils, Users, Baby } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Button } from './ui/button';

export function FoodSection() {
  const [activeCategory, setActiveCategory] = useState<'officials' | 'family'>('officials');

  const officialsFood = [
    {
      name: '다식',
      description: '고운 가루로 만든 전통 과자로, 다양한 맛과 색깔을 자랑합니다.',
      ingredients: '녹두가루, 송화가루, 검은깨가루',
      image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjB0cmFkaXRpb25hbCUyMGRlc3NlcnR8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      name: '정과',
      description: '각종 과일이나 뿌리를 꿀이나 설탕에 조린 달콤한 궁중 간식입니다.',
      ingredients: '생강, 도라지, 연근, 꿀',
      image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjB0cmFkaXRpb25hbCUyMGRlc3NlcnR8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      name: '강정',
      description: '찹쌀로 만든 과자에 꿀을 발라 고소하고 달콤한 맛이 일품입니다.',
      ingredients: '찹쌀, 꿀, 참깨, 잣',
      image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjB0cmFkaXRpb25hbCUyMGRlc3NlcnR8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  const familyFood = [
    {
      name: '화전',
      description: '찹쌀가루로 만든 반죽에 꽃잎을 올려 부친 아름다운 전통 간식입니다.',
      ingredients: '찹쌀가루, 진달래꽃, 꿀',
      image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjB0cmFkaXRpb25hbCUyMGRlc3NlcnR8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      name: '송편',
      description: '쌀가루로 만든 떡 안에 달콤한 소를 넣고 솔잎을 깔고 찐 전통 떡입니다.',
      ingredients: '쌀가루, 팥, 깨, 솔잎',
      image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjB0cmFkaXRpb25hbCUyMGRlc3NlcnR8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      name: '약과',
      description: '밀가루 반죽을 기름에 튀기고 꿀을 입힌 달콤하고 바삭한 전통 과자입니다.',
      ingredients: '밀가루, 참기름, 꿀, 계피',
      image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjB0cmFkaXRpb25hbCUyMGRlc3NlcnR8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  const currentFoods = activeCategory === 'officials' ? officialsFood : familyFood;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card rounded-2xl p-6 text-center"
      >
        <div className="flex items-center justify-center gap-2 mb-4">
          <Utensils className="text-white" size={24} />
          <h2 className="text-white">궁중병과</h2>
        </div>
        <p className="text-white/80">
          조선시대 궁중에서 즐겨 먹던 전통 병과를 직접 맛보실 수 있습니다.
        </p>
        
        {/* Category Selection */}
        <div className="flex space-x-2 mt-6">
          <Button
            variant={activeCategory === 'officials' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveCategory('officials')}
            className={`flex-1 flex items-center gap-2 ${
              activeCategory === 'officials'
                ? 'bg-white/30 text-white hover:bg-white/40'
                : 'text-white/80 hover:bg-white/20 hover:text-white'
            }`}
          >
            <Users size={16} />
            문무백관용
          </Button>
          <Button
            variant={activeCategory === 'family' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveCategory('family')}
            className={`flex-1 flex items-center gap-2 ${
              activeCategory === 'family'
                ? 'bg-white/30 text-white hover:bg-white/40'
                : 'text-white/80 hover:bg-white/20 hover:text-white'
            }`}
          >
            <Baby size={16} />
            동반가족용
          </Button>
        </div>
      </motion.div>

      {/* Food Grid */}
      <motion.div
        key={activeCategory}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-1 gap-4"
      >
        {currentFoods.map((food, index) => (
          <motion.div
            key={food.name}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className="glass-card rounded-2xl overflow-hidden"
            whileHover={{ scale: 1.02 }}
          >
            <div className="w-full h-32 overflow-hidden">
              <ImageWithFallback
                src={food.image}
                alt={food.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-4">
              <h3 className="text-white mb-2">{food.name}</h3>
              <p className="text-white/80 text-sm mb-3">{food.description}</p>
              <div className="bg-white/10 rounded-lg p-2">
                <p className="text-white/70 text-xs">주요 재료</p>
                <p className="text-white text-sm">{food.ingredients}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-card rounded-2xl p-6"
      >
        <h3 className="text-white mb-4">시식 안내</h3>
        <div className="space-y-3 text-white/80">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>모든 병과는 전통 방식으로 당일 아침에 정성스럽게 준비됩니다.</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>알레르기가 있으신 분은 사전에 말씀해 주시기 바랍니다.</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>시식은 경춘전에서 진행되며, 전통 차와 함께 제공됩니다.</span>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
            <span>체험 참가자와 동반가족 모두 무료로 시식 가능합니다.</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}