import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Calendar, Clock, Users, ChevronDown, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Button } from './ui/button';

export function ProgramSection() {
  const [activeSubSection, setActiveSubSection] = useState<'overview' | 'details' | 'schedule'>('overview');

  const subSections = [
    { id: 'overview', label: '행사 개요' },
    { id: 'details', label: '프로그램 상세' },
    { id: 'schedule', label: '상세 일정' }
  ] as const;

  const programDetails = [
    {
      title: '문무백관 체험',
      description: '조선시대 관복을 직접 착용하고 궁중 예법을 체험해보는 프로그램입니다.',
      icon: Users
    },
    {
      title: '외명부 체험',
      description: '왕비와 후궁들의 한복을 착용하고 궁중 여성들의 생활을 체험합니다.',
      icon: Users
    },
    {
      title: '궁중연회',
      description: '전통 궁중음식을 맛보며 조선시대 연회 문화를 경험합니다.',
      icon: Clock
    }
  ];

  const scheduleItems = [
    { time: '13:30', activity: '접수 및 안내', location: '창경궁 입구' },
    { time: '14:00', activity: '문무백관 체험', location: '명정전' },
    { time: '15:00', activity: '외명부 체험', location: '통명전' },
    { time: '15:30', activity: '궁중병과 시식', location: '경춘전' },
    { time: '16:30', activity: '궁중연회 및 공연', location: '명정전 앞마당' },
    { time: '18:00', activity: '기념사진 촬영', location: '각 전각' },
    { time: '19:30', activity: '행사 마무리', location: '창경궁 출구' }
  ];

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card rounded-2xl p-6 text-center"
      >
        <div className="flex items-center justify-center gap-2 mb-4">
          <Calendar className="text-white" size={24} />
          <h2 className="text-white">프로그램 안내</h2>
        </div>
        <p className="text-white/80">
          창경궁에서 펼쳐지는 특별한 궁중문화 체험 프로그램을 소개합니다.
        </p>
        
        {/* Sub Navigation */}
        <div className="flex space-x-2">
          {subSections.map((section) => (
            <Button
              key={section.id}
              variant={activeSubSection === section.id ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveSubSection(section.id)}
              className={`flex-1 ${
                activeSubSection === section.id
                  ? 'bg-white/30 text-white hover:bg-white/40'
                  : 'text-white/80 hover:bg-white/20 hover:text-white'
              }`}
            >
              {section.label}
            </Button>
          ))}
        </div>
      </motion.div>

      {/* Content */}
      {activeSubSection === 'overview' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="glass-card rounded-2xl p-6">
            <h3 className="text-white mb-4">창경궁 궁중연회 행사 개요</h3>
            <div className="w-full h-48 rounded-xl overflow-hidden mb-4">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1587484789196-e1edf30f749a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjB0cmFkaXRpb25hbCUyMGhhbmJvayUyMGNvc3R1bWV8ZW58MXx8fHwxNzU4OTk5NjU3fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="궁중연회 체험"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="space-y-3 text-white/90">
              <p>조선왕조의 전통과 격식을 현대에 재현하는 특별한 문화체험 행사입니다.</p>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div className="bg-white/10 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock size={16} className="text-white" />
                    <span className="text-white">일시</span>
                  </div>
                  <p className="text-white/80">2024년 10월 26일 (토)</p>
                  <p className="text-white/80">13:30 - 20:00</p>
                </div>
                <div className="bg-white/10 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Users size={16} className="text-white" />
                    <span className="text-white">장소</span>
                  </div>
                  <p className="text-white/80">창경궁 일대</p>
                  <p className="text-white/80">(명정전, 통명전 등)</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {activeSubSection === 'details' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          {programDetails.map((detail, index) => {
            const Icon = detail.icon;
            const isExpanded = true; // 항상 확장된 상태로 표시
            
            return (
              <motion.div
                key={detail.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass-card rounded-2xl p-4"
              >
                <button className="w-full flex items-center justify-between text-left">
                  <div className="flex items-center gap-3">
                    <Icon size={20} className="text-white" />
                    <span className="text-white">{detail.title}</span>
                  </div>
                  {isExpanded ? <ChevronDown className="text-white" /> : <ChevronRight className="text-white" />}
                </button>
                
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    className="mt-3 pl-8"
                  >
                    <p className="text-white/80">{detail.description}</p>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </motion.div>
      )}

      {activeSubSection === 'schedule' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card rounded-2xl p-6"
        >
          <h3 className="text-white mb-6">상세 타임테이블</h3>
          <div className="space-y-4">
            {scheduleItems.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-4 p-3 bg-white/10 rounded-lg"
              >
                <div className="text-white bg-white/20 rounded-lg px-3 py-1 min-w-fit">
                  {item.time}
                </div>
                <div className="flex-1">
                  <p className="text-white">{item.activity}</p>
                  <p className="text-white/70 text-sm">{item.location}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}