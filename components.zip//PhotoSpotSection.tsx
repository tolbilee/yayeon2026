import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Camera, MapPin, Lightbulb, ChevronDown, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function PhotoSpotSection() {
  const [expandedSpot, setExpandedSpot] = useState<string | null>(null);
  const [showTips, setShowTips] = useState(false);

  const photoSpots = [
    {
      id: 'myeongjeongjeon',
      name: '명정전 앞',
      description: '창경궁의 정전으로, 웅장한 건물을 배경으로 한 기념사진 촬영이 가능합니다.',
      features: [
        '웅장한 전각 건물을 배경으로 촬영',
        '넓은 마당에서 여유로운 촬영 가능',
        '조선시대 왕의 정전에서의 특별한 경험',
        '단체 사진 촬영에 최적'
      ],
      bestTime: '오후 3시-5시 (햇빛이 부드러워지는 시간)',
      tips: '명정전의 웅장함을 살리기 위해 건물 전체가 나오도록 촬영하세요.',
      image: 'https://images.unsplash.com/photo-1712617151110-5362497b8475?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBwYWxhY2UlMjBjaGFuZ2d5ZW9uZ2d1bmd8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 'okcheonbridge',
      name: '옥천교 위',
      description: '아름다운 돌다리 위에서 전통적인 분위기의 사진을 촬영할 수 있는 로맨틱한 장소입니다.',
      features: [
        '조선시대 전통 석교의 아름다움',
        '다리 아래 흐르는 물과 조화로운 풍경',
        '한복과 잘 어울리는 고전적 배경',
        '커플 사진이나 가족 사진에 인기'
      ],
      bestTime: '오후 4시-6시 (황금빛 조명이 아름다운 시간)',
      tips: '다리의 곡선미를 살리는 각도에서 촬영하면 더욱 아름답습니다.',
      image: 'https://images.unsplash.com/photo-1712617151110-5362497b8475?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBwYWxhY2UlMjBjaGFuZ2d5ZW9uZ2d1bmd8ZW58MXx8fHwxNzU5MDI5MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  const photographyTips = [
    {
      category: '한복 촬영 팁',
      tips: [
        '치마의 볼륨감을 살리기 위해 바람이 있는 날 살짝 펼쳐보세요',
        '저고리의 곡선미가 돋보이도록 자세를 취해보세요',
        '전통 소품(부채, 노리개 등)을 활용하면 더욱 운치있는 사진이 가능합니다',
        '한복의 색감과 배경이 조화를 이루도록 촬영 위치를 선택하세요'
      ]
    },
    {
      category: '조명 활용법',
      tips: [
        '황금시간대(일몰 1-2시간 전)를 활용하면 따뜻하고 부드러운 사진을 얻을 수 있습니다',
        '건물의 그림자를 활용하여 자연스러운 음영 효과를 연출하세요',
        '역광을 활용하면 실루엣 효과로 신비로운 분위기를 만들 수 있습니다',
        '흐린 날씨에는 자연스러운 소프트박스 효과로 균등한 조명을 얻을 수 있습니다'
      ]
    },
    {
      category: '구도와 앵글',
      tips: [
        '건물의 선을 활용하여 자연스러운 프레임 효과를 만들어보세요',
        '낮은 앵글에서 촬영하면 더욱 위엄있고 웅장한 느낌을 줄 수 있습니다',
        '3분할 법칙을 활용하여 균형잡힌 구도를 만들어보세요',
        '배경의 복잡함을 피하고 깔끔한 배경을 선택하세요'
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card rounded-2xl p-6 text-center"
      >
        <div className="flex items-center justify-center gap-2 mb-4">
          <Camera className="text-white" size={24} />
          <h2 className="text-white">포토 핫스팟</h2>
        </div>
        <p className="text-white/80">
          창경궁의 아름다운 전각들과 함께 특별한 추억을 남겨보세요.
        </p>
      </motion.div>

      {/* Photo Spots */}
      <div className="space-y-4">
        {photoSpots.map((spot) => {
          const isExpanded = expandedSpot === spot.id;
          
          return (
            <motion.div
              key={spot.id}
              className="glass-card rounded-2xl overflow-hidden"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <button
                onClick={() => setExpandedSpot(isExpanded ? null : spot.id)}
                className="w-full p-4 flex items-center justify-between text-left"
              >
                <div className="flex items-center gap-3">
                  <MapPin size={20} className="text-white" />
                  <div>
                    <h3 className="text-white">{spot.name}</h3>
                    <p className="text-white/70 text-sm">{spot.description}</p>
                  </div>
                </div>
                {isExpanded ? <ChevronDown className="text-white" /> : <ChevronRight className="text-white" />}
              </button>
              
              {isExpanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-4 pb-4"
                >
                  <div className="w-full h-40 rounded-lg overflow-hidden mb-4">
                    <ImageWithFallback
                      src={spot.image}
                      alt={spot.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-white mb-2">특징</h4>
                      <div className="space-y-2">
                        {spot.features.map((feature, index) => (
                          <div key={index} className="flex items-start gap-2">
                            <div className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-white/80 text-sm">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 gap-3">
                      <div className="bg-white/10 rounded-lg p-3">
                        <p className="text-white/70 text-sm mb-1">최적 촬영 시간</p>
                        <p className="text-white text-sm">{spot.bestTime}</p>
                      </div>
                      <div className="bg-white/10 rounded-lg p-3">
                        <p className="text-white/70 text-sm mb-1">촬영 팁</p>
                        <p className="text-white text-sm">{spot.tips}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Photography Tips Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-card rounded-2xl overflow-hidden"
      >
        <button
          onClick={() => setShowTips(!showTips)}
          className="w-full p-4 flex items-center justify-between text-left"
        >
          <div className="flex items-center gap-3">
            <Lightbulb size={20} className="text-white" />
            <h3 className="text-white">사진촬영 팁</h3>
          </div>
          {showTips ? <ChevronDown className="text-white" /> : <ChevronRight className="text-white" />}
        </button>
        
        {showTips && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="px-4 pb-4"
          >
            <div className="space-y-4">
              {photographyTips.map((category, index) => (
                <motion.div
                  key={category.category}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white/5 rounded-lg p-4"
                >
                  <h4 className="text-white mb-3">{category.category}</h4>
                  <div className="space-y-2">
                    {category.tips.map((tip, tipIndex) => (
                      <div key={tipIndex} className="flex items-start gap-2">
                        <div className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-white/80 text-sm">{tip}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}